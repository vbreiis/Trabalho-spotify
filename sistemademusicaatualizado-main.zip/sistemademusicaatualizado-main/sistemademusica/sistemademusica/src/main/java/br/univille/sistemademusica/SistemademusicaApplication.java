package br.univille.sistemademusica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemademusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemademusicaApplication.class, args);
	}

}
